angular.module("HalloCasaAdmin.environment.constants", [])
.constant("backend_url", "http://www.hallocasa.com:64647/hallocasa-api/")
.constant("user_images_url", "http://www.hallocasa.com:64645/resources/images/users/")
.constant("property_images_url", "http://www.hallocasa.com:64645/resources/images/properties/")
.constant("security_key", "4h4h4&gfhgk6eddy5%gjhdkkd6lsu");
