# Project test using AngularJS and Material

## Requaries 
* Node v7.10

## Start Project
1. run >npm install // install dependencies
2. run >bower install // install librarys
3. run >bower build // make public folder 